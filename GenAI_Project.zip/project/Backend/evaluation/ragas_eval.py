from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv
import os
import json

load_dotenv()

# Initialize Gemini LLM
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0.0,  
    google_api_key=os.getenv("GEMINI_API_KEY")
)

# Evaluation prompt template
EVALUATION_PROMPT = """
You are an expert evaluator of research paper summaries. Compare the model-generated summary against the human reference summary.

Question/Prompt:
{question}

Human Reference Summary:
{reference}

Model-generated Summary:
{model}

Instructions:
1. Evaluate on the following metrics (scale 1-5, 5 is best):
   - Faithfulness: How factually correct is the summary compared to the reference.
   - ContextPrecision: How accurate and relevant are the included details.
   - ContextRecall: How well important points from the reference are covered.
   - ResponseRelevancy: How useful and informative is the summary.

2. Provide a JSON output in the following format ONLY:

{{
    "Faithfulness": <score>,
    "ContextPrecision": <score>,
    "ContextRecall": <score>,
    "ResponseRelevancy": <score>
}}

Do not add any extra explanation or text.
"""

def evaluate_summary(dataset):
    """
    Evaluate a dataset using Gemini LLM.
    
    Args:
        dataset: list of dicts, each entry should have:
            - 'user_input': the input prompt or title
            - 'response': model summary
            - 'reference': human reference summary

    Returns:
        list of dicts: JSON containing scores for each metric.
    """
    all_results = []

    for entry in dataset:
        prompt = EVALUATION_PROMPT.format(
            question=entry.get('user_input', ''),
            reference=entry['reference'],
            model=entry['response']
        )
        out = llm.invoke(prompt)

        # Parse LLM output as JSON
        try:
            scores = json.loads(out.content.strip())
        except Exception:
            scores = {
                "Faithfulness": None,
                "ContextPrecision": None,
                "ContextRecall": None,
                "ResponseRelevancy": None
            }

        all_results.append(scores)

    return all_results

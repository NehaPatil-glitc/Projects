# Backend/main.py
# Run from project root: uvicorn Backend.main:app --reload

import os
from dotenv import load_dotenv
import sys, pathlib
from fastapi import FastAPI, UploadFile, File, HTTPException

# Ensure project root is on sys.path so relative imports work
sys.path.append(str(pathlib.Path(__file__).resolve().parent.parent))
load_dotenv()  # loads .env in project root

# Project imports
from Backend.utils.pdf_reader import extract_text_from_pdf, extract_text_from_pdf_bytes
from Backend.agents.summarizer_agent import run_summarizer
from Backend.agents.comparison_agent import run_comparison
from Backend.evaluation.ragas_eval import evaluate_summary

app = FastAPI(title="Research Paper Assistant")

# Directory for uploaded PDFs
UPLOAD_DIR = os.path.join(str(pathlib.Path(__file__).resolve().parent.parent), "uploaded_pdfs")
os.makedirs(UPLOAD_DIR, exist_ok=True)


@app.get("/")
def home():
    return {"status": "ok", "message": "Research Paper Assistant running"}


# ----------------- PDF Upload -----------------
@app.post("/upload-pdf/")
async def upload_pdf(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are accepted")
    dest = os.path.join(UPLOAD_DIR, file.filename)
    contents = await file.read()
    with open(dest, "wb") as f:
        f.write(contents)
    text = extract_text_from_pdf(dest)
    return {"filename": file.filename, "path": dest, "extracted_text_snippet": text[:1000]}


# ----------------- Summarization -----------------
@app.post("/summarize/")
async def summarize_from_text(payload: dict):
    text = payload.get("text")
    if not text:
        raise HTTPException(status_code=400, detail="Provide 'text' in JSON body")
    summary = run_summarizer(text)
    return {"summary": summary}


@app.post("/summarize-file/")
async def summarize_from_file(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are accepted")
    contents = await file.read()
    text = extract_text_from_pdf_bytes(contents)
    summary = run_summarizer(text)
    return {"filename": file.filename, "summary": summary}


# ----------------- Text Comparison -----------------
@app.post("/compare/")
async def compare_texts(payload: dict):
    t1 = payload.get("text1")
    t2 = payload.get("text2")
    if not t1 or not t2:
        raise HTTPException(status_code=400, detail="Provide 'text1' and 'text2' in JSON body")
    cmp = run_comparison(t1, t2)
    return {"comparison": cmp}


@app.post("/compare-files/")
async def compare_files(file1: UploadFile = File(...), file2: UploadFile = File(...)):
    if not (file1.filename.lower().endswith(".pdf") and file2.filename.lower().endswith(".pdf")):
        raise HTTPException(status_code=400, detail="Only PDF files are accepted")
    c1 = await file1.read()
    c2 = await file2.read()
    t1 = extract_text_from_pdf_bytes(c1)
    t2 = extract_text_from_pdf_bytes(c2)
    cmp = run_comparison(t1, t2)
    return {"file1": file1.filename, "file2": file2.filename, "comparison": cmp}


# ----------------- Ragas Evaluation -----------------
# ----------------- Gemini-based Evaluation -----------------
@app.post("/evaluate-summary/")
async def evaluate_api(payload: dict):
    """
    Evaluate a model-produced summary against a reference using Gemini LLM.
    JSON body:
    {
      "question": "short prompt used or title",
      "reference": "human reference summary",
      "model": "model generated summary"
    }
    """
    question = payload.get("question", "")
    reference = payload.get("reference", "")
    model = payload.get("model", "")

    if not reference or not model:
        raise HTTPException(status_code=400, detail="Provide 'reference' and 'model' fields")

    # Wrap input into dataset format
    dataset = [
        {"user_input": question, "response": model, "reference": reference}
    ]

    # Import the new Gemini-based evaluator
    from Backend.evaluation.ragas_eval import evaluate_summary

    # Call Gemini LLM to evaluate
    scores = evaluate_summary(dataset)

    return {"gemini_scores": scores}


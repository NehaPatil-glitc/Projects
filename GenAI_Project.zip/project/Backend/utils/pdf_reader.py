# Backend/utils/pdf_reader.py
from typing import Union
import io
import PyPDF2

def extract_text_from_pdf(path: str) -> str:
    with open(path, "rb") as fh:
        reader = PyPDF2.PdfReader(fh)
        text = []
        for p in reader.pages:
            page_text = p.extract_text()
            if page_text:
                text.append(page_text)
    return "\n\n".join(text).strip()

def extract_text_from_pdf_bytes(pdf_bytes: Union[bytes, io.BytesIO]) -> str:
    if isinstance(pdf_bytes, bytes):
        fh = io.BytesIO(pdf_bytes)
    else:
        fh = pdf_bytes
    reader = PyPDF2.PdfReader(fh)
    text = []
    for p in reader.pages:
        page_text = p.extract_text()
        if page_text:
            text.append(page_text)
    return "\n\n".join(text).strip()

# Backend/agents/comparison_agent.py
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv
import os

load_dotenv()

llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0.15,
    google_api_key=os.getenv("GEMINI_API_KEY")
)

COMPARE_PROMPT = """
You are an expert evaluator. Compare two research papers or texts and produce a **clear, concise, and ultra-readable output** in Markdown.

1) Start with a short comparative paragraph (3-4 sentences) highlighting the main differences:
   - Goals / Objectives
   - Methods / Approach
   - Key Results
   - Overall significance

2)Objective | Methods | Dataset | Key Results | Strengths | Weaknesses | Best Use-case

3) End with a ranked judgement (1-2 lines) stating which paper is stronger and why.

Instructions:
- Keep sentences short and to the point.
- Use bullet points in table cells only if needed for clarity.
- Maintain all given facts; do **not invent numbers**.
- Make it easy to read for both technical and non-technical readers.



"""

def run_comparison(text1: str, text2: str) -> str:
    prompt = f"{COMPARE_PROMPT}\n\n--- PAPER 1 ---\n{text1}\n\n--- PAPER 2 ---\n{text2}\n\nComparison:"
    out = llm.invoke(prompt)

    # Clean up output
    content = out.content.strip()  # remove leading/trailing whitespace
    lines = content.split("\n")

    # Remove consecutive blank lines
    clean_lines = []
    for line in lines:
        if line.strip() == "" and (len(clean_lines) == 0 or clean_lines[-1].strip() == ""):
            continue
        clean_lines.append(line.strip())

    # Join lines back
    cleaned_output = "\n".join(clean_lines)

    return cleaned_output

# Backend/agents/summarizer_agent.py
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv
import os
load_dotenv()

# Use API-key mode to avoid Google ADC issues
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0.2,
    google_api_key=os.getenv("GEMINI_API_KEY")
)

SUMMARY_PROMPT = """You are an expert research paper summarizer. Produce a clear, concise, and well-structured scholarly summary in Markdown. Use headers and bullet points.
For this *single* paper generate the following sections exactly:

# Title: <paper title or filename>
## 1) One-line summary
- (1 short sentence)

## 2) Background & Motivation
- 2-4 short bullets describing the research context and why it matters.

## 3) Objective / Research Questions
- The main aim(s) of the paper, crisp.

## 4) Methods / Approach
- 3-6 bullets describing dataset(s), model/technique, experimental setup.

## 5) Key Results (quantitative if available)
- 3 bullets with important numbers, metrics, or findings.

## 6) Contributions & Novelty
- 2-4 bullets.

## 7) Strengths
- 2 bullets.

## 8) Weaknesses / Limitations
- 2 bullets.

## 9) Future Work / Open Questions
- 2 bullets.

## 10) Short "how it compares" note (1-2 lines)
- One or two sentences that can be used later for pairwise comparison.

Be concise but concrete. When the text doesn't contain numbers, say "no explicit numeric results provided" rather than invent numbers.".
"""

def run_summarizer(text: str) -> str:
    prompt = f"{SUMMARY_PROMPT}\n\nPaper text:\n{text}\n\nSummary:"
    out = llm.invoke(prompt)
    return out.content
